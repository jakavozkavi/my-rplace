const express = require('express');
const app = express();
const http = require('http').Server(app);
const io = require('socket.io')(http);
const fs = require('fs');

const PORT = process.env.PORT || 3000;

// Завантаження існуючого полотна або створення нового
let canvas = {};
if (fs.existsSync('canvas.json')) {
    canvas = JSON.parse(fs.readFileSync('canvas.json', 'utf8'));
}

// Доступ до папки "public"
app.use(express.static('public'));

// WebSocket для реального часу
io.on('connection', socket => {
    console.log('🔌 Користувач підключився');
    socket.emit('load', canvas);

    socket.on('pixel', data => {
        canvas[`${data.x},${data.y}`] = data.color;
        io.emit('pixel', data);
        fs.writeFileSync('canvas.json', JSON.stringify(canvas));
    });

    socket.on('disconnect', () => console.log('❌ Користувач відключився'));
});

// Запуск сервера
http.listen(PORT, () => console.log(`🚀 Сервер працює на порту ${PORT}`));
