const socket = io();
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const pixelSize = 10;

let color = 'black'; // Початковий колір

// Заповнення полотна при підключенні
socket.on('load', pixels => {
    for (let key in pixels) {
        let [x, y] = key.split(',').map(Number);
        ctx.fillStyle = pixels[key];
        ctx.fillRect(x * pixelSize, y * pixelSize, pixelSize, pixelSize);
    }
});

// Малювання пікселя та відправка на сервер
canvas.addEventListener('click', event => {
    let x = Math.floor(event.offsetX / pixelSize);
    let y = Math.floor(event.offsetY / pixelSize);

    socket.emit('pixel', { x, y, color });

    ctx.fillStyle = color;
    ctx.fillRect(x * pixelSize, y * pixelSize, pixelSize, pixelSize);
});

// Оновлення при зміні пікселя іншим гравцем
socket.on('pixel', data => {
    ctx.fillStyle = data.color;
    ctx.fillRect(data.x * pixelSize, data.y * pixelSize, pixelSize, pixelSize);
});
